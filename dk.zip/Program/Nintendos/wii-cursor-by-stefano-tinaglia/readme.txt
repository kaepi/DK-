﻿=== Nintendo Wii Cursor Set ===

By: stefanotinaglia99 (http://www.rw-designer.com/user/22903)

Download: http://www.rw-designer.com/cursor-set/wii-cursor-by-stefano-tinaglia

Author's decription:

Wii Cursors by Stefano Tinaglia

==========

License: Custom

You are free:

* To Use the work for personal noncommercial purposes.

For any other use, you must contact the author and ask for permission.